import axios from "axios";
import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Navbar2 from "../components/Navbar2";

function Update() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [inputData, setInputData] = useState({
    requestId: "",
    user: {
      id: "",
      name: "",
      emailid: "",
      address: "",
      phoneNumber: "",
      donation: "",
      status: ""
    }
  });

  useEffect(() => {
    // Fetch order details based on ID when component mounts
    axios
      .get(`http://localhost:1010/request/${id}`)
      .then((response) => {
        const { requestId, user } = response.data;
        setInputData({
          requestId,
          user: {
            id: user.id,
            name: user.name,
            emailid: user.emailid,
            address: user.address,
            phoneNumber: user.phoneNumber,
            donation: user.donation,
            status: user.status
          }
        });
      })
      .catch((err) => console.log(err));

    // Fetch all users to populate the dropdown (if needed)
    // axios
    //   .get("http://localhost:1010/user/all")
    //   .then((response) => setUsers(response.data))
    //   .catch((err) => console.log(err));
  }, [id]);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setInputData({
      ...inputData,
      user: {
        ...inputData.user,
        [name]: value
      }
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios
      .put(`http://localhost:1010/request/${id}`, inputData)
      .then((res) => {
        console.log(res.data); // Log response data for verification
        alert("Data updated Successfully");
        navigate("/main"); // Navigate to home page after successful submission
      })
      .catch((err) => console.error("Error submitting data:", err));
  };

  return (
    <>
      <Navbar2 />
      <div
        id="edit"
        className="d-flex w-100 vh-100 justify-content-center align-items-center"
        style={{ backdropFilter: 'blur(5px)', backgroundColor: '#f9f9f9' }}
      >
        <div className="w-50 border bg-dark p-5" style={{ animation: 'fadeIn 0.5s', border: '4px solid black', borderRadius: '30px' }}>
          <form onSubmit={handleSubmit}>
            <h1 style={{ marginBottom: '20px', color: '#fff', fontFamily: 'Arial, sans-serif' }}>
              UPDATE STATUS
            </h1>

            <div className="mb-3">
              <label htmlFor="requestId"> Request ID:</label>
              <input
                type="number"
                disabled
                name="requestId"
                className="form-control"
                value={inputData.requestId}
                onChange={(e) => setInputData({ ...inputData, requestId: e.target.value })}
              />
            </div>

            <div className="mb-3">
              <label htmlFor="userId"> User ID:</label>
              <input
                id="userId"
                name="id"
                className="form-control"
                value={inputData.user.id}
                disabled
              />
            </div>

            <div className="mb-3">
              <label htmlFor="name" className="form-label">
                Name
              </label>
              <input
                type="text"
                name="name"
                className="form-control"
                value={inputData.user.name}
                onChange={handleChange}
                required
              />
            </div>

            <div className="mb-3">
              <label htmlFor="emailid" className="form-label">
                Email ID
              </label>
              <input
                type="email"
                name="emailid"
                className="form-control"
                value={inputData.user.emailid}
                onChange={handleChange}
                required
              />
            </div>

            <div className="mb-3">
              <label htmlFor="address" className="form-label">
                Address
              </label>
              <input
                type="text"
                name="address"
                className="form-control"
                value={inputData.user.address}
                onChange={handleChange}
                required
              />
            </div>

            <div className="mb-3">
              <label htmlFor="phoneNumber" className="form-label">
                Phone Number
              </label>
              <input
                type="tel"
                name="phoneNumber"
                className="form-control"
                value={inputData.user.phoneNumber}
                onChange={handleChange}
                required
              />
            </div>

            <div className="mb-3">
              <label htmlFor="donation" className="form-label">
                Donation
              </label>
              <input
                type="text"
                name="donation"
                className="form-control"
                value={inputData.user.donation}
                onChange={handleChange}
                required
              />
            </div>

            <div className="mb-3">
              <label htmlFor="status" className="form-label">
                Status
              </label>
              <input
                id="status"
                name="status"
                className="form-control"
                value={inputData.user.status}
                onChange={handleChange}
                required 
              />
            </div>

            <button type="submit" className="btn btn-info" style={{ fontSize: '16px', padding: '10px 20px' }}>
              Update Status
            </button>
          </form>
        </div>
      </div>
    </>
  );
}

export default Update;
