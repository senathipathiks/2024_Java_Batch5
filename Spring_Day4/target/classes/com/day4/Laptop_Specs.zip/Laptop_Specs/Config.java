package com.day4.Laptop_Specs;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "com.day4.Laptop_Specs")
public class Config {
}
