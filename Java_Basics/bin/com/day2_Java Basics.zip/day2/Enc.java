package com.day2;

import java.util.Scanner;

public class Enc {
	static void doEnc() {
		System.out.println("Cipher Key is:");
		char[] c = null;
		for(int i=0;i<c.length;i++) {
			if(c[i]!=0) {
				c[i]=(char) (c[i]+6);
				System.out.print(c[i]);
			}
		}
	}
	
	static void doDec() {
		System.out.println("Decrypted Key is:");
		int[] c = null ;
		for(int i=0;i<c.length;i++) {
			if(c[i]!=0) {
				c[i]=(char) (c[i]-6);
				System.out.print(c[i]);
			}
		}
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		

		System.out.println("Enter Your Choice:");
		System.out.println("1.Encryption\t 2.Decryption");
		int ch=sc.nextInt();
		
		System.out.println("Enter the String: ");
		String in = sc.next();
		
		char c[] = in.toCharArray();
		
		switch(ch) {
		case 1:
			doEnc();
			break;
		case 2:
			doDec();
			break;
		}
	}
}
