package com.assessment.codequality.serviceimplementation;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.assessment.codequality.model.Registration;

@SpringBootTest
class RegistrationServiceImplementationTest {

	@Autowired
    private RegistrationServiceImplementation registrationService;

    

    @Test
    void testAddRegistration() {
        Registration registration = new Registration(0, "suriya", "donator", "sss@gmail.com", "suriya123");
        
        assertEquals("success", registrationService.addRegistration(registration));
    }
    
    @Test
    void testAddRegistrationFailure() {
        Registration registration = null;
        
        assertEquals("failure", registrationService.addRegistration(registration));
    }
	
	
    
    @Test
  void testUpdateRegistration() {
      Registration obj = new Registration(6, "nandha", "employee", "nnn@gmail.com", "nandha123");
      registrationService.updateRegistration(obj); 
      obj.setName("Suriyakumaran");
      assertEquals("success", registrationService.updateRegistration(obj));
      
      Registration retrievedRegistration = registrationService.getRegistration(6);
      assertNotNull(retrievedRegistration);
      assertEquals("Suriyakumaran", retrievedRegistration.getName());
  }

  @Test
  void testUpdateRegistrationNull() {
      Registration obj = null;
      assertEquals("failure", registrationService.updateRegistration(obj));
  }
  
  

  @Test
  void testGetRegistration() {     
      
      Registration retrievedRegistration = registrationService.getRegistration(8);
      assertNotNull(retrievedRegistration);
      assertEquals("ponraj", retrievedRegistration.getName());
      assertEquals("nandha123", retrievedRegistration.getPassword());
  }

  @Test
  void testGetRegistration_NotFound() {
	  Registration retrievedRegistration = registrationService.getRegistration(99);
      assertNull(retrievedRegistration);
  }

  @Test
  void testDeleteRegistration() {
      assertEquals("success", registrationService.deleteRegistrationById(9));
  }

  @Test
  void testDeleteRegistrationNotFound() {
      assertEquals("failure", registrationService.deleteRegistrationById(100));
  }

    
}

