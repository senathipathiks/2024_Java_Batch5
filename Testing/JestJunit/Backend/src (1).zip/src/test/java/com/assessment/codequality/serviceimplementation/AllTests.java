package com.assessment.codequality.serviceimplementation;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

@Suite
@SelectClasses({ RegistrationServiceImplementationTest.class, RequestServiceImplementationTest.class,
		UserServiceImplementationTest.class })
public class AllTests {

}
