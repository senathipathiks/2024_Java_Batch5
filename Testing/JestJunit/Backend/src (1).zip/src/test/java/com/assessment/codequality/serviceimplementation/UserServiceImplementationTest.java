package com.assessment.codequality.serviceimplementation;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.assessment.codequality.model.User;
import com.assessment.codequality.service.UserService;



@SpringBootTest
class UserServiceImplementationTest {

    @Autowired
    private UserService userService;


    @Test
    void testSaveUser() {
        User obj = new User(0, "Nagarjun", "naga@gmail.com", "Madurai", 123456789, "Money", "Pending");
        assertEquals("success", userService.saveAddUser(obj));
    }

    @Test
    void testSaveUserNull() {
        User obj = null;
        assertEquals("failure", userService.saveAddUser(obj));
    }

    @Test
    void testUpdateUser() {
        User obj = new User(6, "nandha", "nnn@gmail.com", "Madurai", 123456789, "Dress", "Pending");
        userService.updateIdUser(obj); 
        obj.setName("Gokul");
        assertEquals("success", userService.updateIdUser(obj));
        
        User retrievedUser = userService.getUserById(6);
        assertEquals("Gokul", retrievedUser.getName());
    }

    @Test
    void testUpdateUserNull() {
        User obj = null;
        assertEquals("failure", userService.updateIdUser(obj));
    }

    @Test
    void testGetUserById() {    
        
        User retrievedUser = userService.getUserById(7);
        assertNotNull(retrievedUser);
        assertEquals("ponraj", retrievedUser.getName());
        assertEquals("Dress", retrievedUser.getDonation());
        assertEquals(123456789, retrievedUser.getPhoneNumber());
    }

    @Test
    void testGetUserById_NotFound() {
    	User retrievedUser = userService.getUserById(99);
        assertNull(retrievedUser);
    }

    @Test
    void testDeleteUser() {

        assertEquals("success", userService.deleteIdUser(10));
    }

    @Test
    void testDeleteUserNotFound() {
    	
        assertEquals("failure", userService.deleteIdUser(100));
    }
}
