package com.assessment.codequality.serviceimplementation;


import com.assessment.codequality.model.Request;
import com.assessment.codequality.model.User;
import com.assessment.codequality.repository.RequestRepository;
import com.assessment.codequality.service.RequestService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
class RequestServiceImplementationTest {

	@Autowired
    RequestRepository requestRepository;
	@Autowired
    RequestService requestService;

	@Test
	void testSaveAddRequest() {
		User user = new User(7, "ponraj", "nnn@gmail.com", "Madurai", 123456789, "Dress", "Pending");
		Request obj = new Request(0,user);
		assertEquals("success", requestService.saveAddRequest(obj));
	}
	
	@Test
	void testSaveAddRequest2() {
		Request obj = null;
		assertEquals("failure", requestService.saveAddRequest(obj));
	}

    @Test
    void testGetRequestById() {
        int id = 1;
        Request request = new Request();
        requestRepository.saveRequest(request);

        String result = requestService.getRequestById(id);

        assertEquals("success", result);
    }

    @Test
    void testGetRequestByIdWithNullRequest() {
        int id = 99;

        String result = requestService.getRequestById(id);

        assertEquals("failure", result);
    }


    @Test
    void testUpdateIdRequest() {
    	
    	User user = new User(7, "ponraj", "nnn@gmail.com", "Madurai", 123456789, "Dress", "Pending");
		Request obj = new Request(19,user);
    	
        String result = requestService.updateIdRequest(obj);

        assertEquals("success", result);
    }

    @Test
    void testUpdateIdRequestWithNullRequest() {
        String result = requestService.updateIdRequest(null);

        assertEquals("failure", result);
    }

    @Test
    void testDeleteIdRequest() {
        int id = 18;
        Request request = new Request();
        requestRepository.saveRequest(request);

        String result = requestService.deleteIdRequest(id);

        assertEquals("success", result);
    }

    @Test
    void testDeleteIdRequestWithNonExistingRequest() {
        int id = 100;

        String result = requestService.deleteIdRequest(id);

        assertEquals("failure", result);
    }
}