package com.assessment.codequality.service;

import java.util.List;
import com.assessment.codequality.model.Request;

public interface RequestService {

	String getRequestById(int id);

	String saveAddRequest(Request request);

	String deleteIdRequest(int id);

	String updateIdRequest(Request request);

	List<Request> getAllRequests();

}
