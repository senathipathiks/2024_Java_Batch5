package com.assessment.codequality.repository;

import java.util.List;

import com.assessment.codequality.model.User;
public interface UserRepository {

	User findUById(int id);

	void saveU(User user);

	void deleteU(int id);

	void updateU(User user);

	List<User> findAllUsers();

}
