package com.assessment.codequality.serviceimplementation;

import java.util.List;
import org.springframework.stereotype.Service;

import com.assessment.codequality.model.Registration;
import com.assessment.codequality.repository.RegistrationRepository;
import com.assessment.codequality.service.RegistrationService;


@Service
public class RegistrationServiceImplementation implements RegistrationService {

	RegistrationRepository repo;

	public RegistrationServiceImplementation(RegistrationRepository repo) {
		super();
		this.repo = repo;
	}

	public void addRegistration(Registration rn) {
		  
		 repo.saveRegistration(rn);
	}

	@Override
	public Registration getRegistration(int id) {
		return repo.findRegistrationById(id);
	}

	public List<Registration> getAllRegistration() {
		return repo.findAllRegistration();
	}

	public void updateRegistration(Registration rn) {
		 repo.updateRegistrationById(rn);
	}

	public void deleteRegistrationById(int id) {
		repo.deleteRegistration(id);	
	}
}
