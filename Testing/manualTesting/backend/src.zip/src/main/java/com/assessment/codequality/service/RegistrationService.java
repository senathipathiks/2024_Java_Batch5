package com.assessment.codequality.service;

import java.util.List;

import com.assessment.codequality.model.Registration;

public interface RegistrationService {

	public void addRegistration(Registration rn);

	public Registration getRegistration(int id);

	public List<Registration> getAllRegistration();

	public void updateRegistration(Registration rn);

	public void deleteRegistrationById(int id);
}
