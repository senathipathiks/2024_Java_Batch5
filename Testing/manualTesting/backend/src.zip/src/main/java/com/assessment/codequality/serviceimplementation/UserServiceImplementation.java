package com.assessment.codequality.serviceimplementation;

import java.util.List;

import org.springframework.stereotype.Service;

import com.assessment.codequality.model.User;
import com.assessment.codequality.repository.UserRepository;
import com.assessment.codequality.service.UserService;



@Service
public class UserServiceImplementation implements UserService {

	private final UserRepository repo;

	public UserServiceImplementation(UserRepository repo) {
		this.repo = repo;
	}

	@Override
	public void saveUser(User user) {
		repo.saveU(user);
	}

	@Override
	public User getUserById(int id) {

		return repo.findUById(id);
	}

	@Override
	public List<User> getAllUsers() {

		return repo.findAllUsers();
	}

	@Override
	public void updateUser(User user) {

		repo.updateU(user);

	}

	@Override
	public void deleteUser(int id) {
		repo.deleteU(id);

	}

}
