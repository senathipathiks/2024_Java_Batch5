package com.assessment.codequality.controller;

import org.springframework.web.bind.annotation.*;

import com.assessment.codequality.model.User;
import com.assessment.codequality.service.UserService;

import java.util.List;

@CrossOrigin("http://localhost:3001,http://localhost:3000, http://localhost:3002,http://localhost:3003")
@RestController
@RequestMapping("/user")
public class UserController {

	private final UserService userService;

	public UserController(UserService userService) {
		this.userService = userService;
	}

	@GetMapping("/all")
	public List<User> getAllUsers() {
		return userService.getAllUsers();
	}

	@GetMapping("/{id}")
	public User getUserById(@PathVariable int id) {
		return userService.getUserById(id);
	}

	@PostMapping
	public void createUser(@RequestBody User user) {
		userService.saveUser(user);
	}

	@PutMapping("/{id}")
	public void updateUser(@RequestBody User user) {
		userService.updateUser(user);
	}

	@DeleteMapping("/{id}")
	public void deleteUser(@PathVariable("id") int id) {
		userService.deleteUser(id);
	}
}
