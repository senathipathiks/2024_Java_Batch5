package com.assessment.codequality.serviceimplementation;

import java.util.List;

import org.springframework.stereotype.Service;

import com.assessment.codequality.model.Request;
import com.assessment.codequality.repository.RequestRepository;
import com.assessment.codequality.service.RequestService;

@Service
public class RequestServiceImplementation implements RequestService {

	private final RequestRepository requestRepo;

	public RequestServiceImplementation(RequestRepository requestRepo) {
		this.requestRepo = requestRepo;
	}

	@Override
	public void saveAddRequest(Request request) {
		requestRepo.saveRequest(request);
	}

	@Override
	public Request getRequestById(int id) {

		return requestRepo.findRequestById(id);
	}

	public List<Request> getAllRequests() {

		return requestRepo.findAllRequests();
	}

	@Override
	public void updateIdRequest(Request request) {

		requestRepo.updateRequest(request);

	}

	@Override
	public void deleteIdRequest(int id) {
		requestRepo.deleteRequest(id);

	}

}
